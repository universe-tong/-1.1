//
//  People.h
//  第一次作业1.2
//
//  Created by lwnlwn987 on 2019/4/1.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface People : NSObject
-(void)putout1;
-(void)putout2;
-(void)setAge:(int)age; //set方法没有返回值
-(int)age; //get方法 返回类型为成员变量类型
@end

NS_ASSUME_NONNULL_END
