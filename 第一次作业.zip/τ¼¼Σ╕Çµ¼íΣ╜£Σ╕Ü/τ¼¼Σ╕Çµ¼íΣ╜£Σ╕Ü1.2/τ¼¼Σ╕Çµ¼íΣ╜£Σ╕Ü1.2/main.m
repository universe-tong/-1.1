//
//  main.m
//  第一次作业1.2
//
//  Created by lwnlwn987 on 2019/3/31.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>
#import"People.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
    People *Tim=[[People alloc]init];
    [Tim putout1];
    [Tim putout2];
    [Tim setAge:25];
    [Tim putout1];
    [Tim putout2];
    //People *Tom=[[People alloc]initWithName:age:30 height:185.0];
    // [Tom putout1];
    }
    return 0;
}
