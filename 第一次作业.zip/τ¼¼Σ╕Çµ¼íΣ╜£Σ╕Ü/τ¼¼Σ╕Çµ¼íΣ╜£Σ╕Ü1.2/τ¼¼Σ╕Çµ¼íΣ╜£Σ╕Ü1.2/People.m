//
//  People.m
//  第一次作业1.2
//
//  Created by lwnlwn987 on 2019/4/1.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import "People.h"
@implementation People
{
    int _age;
    float _height;
}
-(instancetype)init //WithName:age:(int)age height:(float)height
{
    self=[super init];
    if(self){
        _age=20;
        _height=180.00;
    }
    return self;
}
-(void)putout1
{
    NSLog(@"年龄:%d",_age);
}
-(void)putout2
{
    NSLog(@"身高：%f",_height);
}
-(void)setAge:(int)age
{
    _age=age;
}
-(int)age
{
    return _age;
}
@end
