//
//  main.m
//  第一次作业1.1
//
//  Created by lwnlwn987 on 2019/3/31.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
    NSString *str1;
    str1=@"aasa,bsbb,ccsc,ddsd";
    NSString * str2;
    str2 = [str1 stringByReplacingOccurrencesOfString:@","withString:@""];
    NSString * str3;
    str3  = [str2 stringByReplacingOccurrencesOfString:@"s"withString:@"*"];
    NSLog(@"%@",str3);
    }
    return 0;
}
