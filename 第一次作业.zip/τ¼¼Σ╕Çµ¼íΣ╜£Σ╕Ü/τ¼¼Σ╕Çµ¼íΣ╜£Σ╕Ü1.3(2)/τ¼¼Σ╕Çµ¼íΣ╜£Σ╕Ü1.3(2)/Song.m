//
//  Song.m
//  第一次作业1.3(2)
//
//  Created by lwnlwn987 on 2019/4/4.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import "Song.h"

@implementation Song
//构造函数 初始化
-(id)initWithName:(NSString *)name andArtist:(NSString *)artist andAlbum:(NSString *)album andLength:(int)length{
    if (self=[super init])
    {_name=name;_artist=artist;_album=album;_length=length;}
    return self;
}

-(NSString *)search{
    NSMutableString *str=[[NSMutableString alloc] init];
    [str appendString:@"["];
    [str appendFormat:@"\t歌名:%@,艺术家:%@,专辑:%@,长度:%g\n",_name,_artist,_album,_length];
    [str appendFormat:@"]"];
    return str;
}

@end
