//
//  Song.h
//  第一次作业1.3(2)
//
//  Created by lwnlwn987 on 2019/4/4.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Song : NSObject
@property NSString* name;
@property NSString* artist;
@property NSString* album;
@property int length;
-(id)initWithName:(NSString *)name andArtist:(NSString*) artist andAlbum:(NSString *)album andLength:(float) length;//构造函数初始化
@end
NS_ASSUME_NONNULL_END
