//
//  Playlist.h
//  第一次作业1.3(2)
//
//  Created by lwnlwn987 on 2019/4/4.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Song.h"
@interface PlayList : NSObject
@property NSString *listName;//播放列表名称
@property NSMutableDictionary *songList;//播放列表内容,song
-(id)initWithListName:(NSString*)listName;//初始化列表名
-(BOOL)add:(Song*)song;//添加歌曲
-(BOOL)delet:(NSString*)songName;//删除歌曲,
@end
