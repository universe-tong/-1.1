//
//  Playlist.m
//  第一次作业1.3(2)
//
//  Created by lwnlwn987 on 2019/4/4.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import "Playlist.h"
@implementation PlayList : NSObject
-(id)initWithListName:(NSString *)listName{
    if (self=[super init]) {
        _listName=listName;
NSMutableDictionary *songList=[NSMutableDictionary dictionaryWithCapacity:100];
        _songList=songList;
    }
    return self;
}
-(BOOL)add:(Song *)song{
    if ([[_songList allKeys] containsObject:song.name]) {
        return NO;
    }else{
        [_songList setObject:song forKey:song.name];
        return YES;
    }
}
-(BOOL)delet:(NSString *)songName{

    if ([[_songList allKeys] containsObject:songName]) {
        [_songList removeObjectForKey:songName];
        return YES;
    }else{
        return NO;
    }
}
-(NSString *)search{
    NSMutableString *str=[[NSMutableString alloc] init];
    [str appendFormat:@"%@:[",_listName];
    for (id key in _songList)
    {[str appendFormat:@"\t%@,",[[_songList objectForKey:key] name]];}
    [str appendFormat:@"]"];
    return str;
}
@end

