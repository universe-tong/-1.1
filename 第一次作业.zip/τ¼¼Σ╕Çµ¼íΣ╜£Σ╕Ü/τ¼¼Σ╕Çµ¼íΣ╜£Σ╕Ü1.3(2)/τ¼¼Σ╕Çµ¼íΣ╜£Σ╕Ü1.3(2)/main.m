//
//  main.m
//  第一次作业1.3(2)
//
//  Created by lwnlwn987 on 2019/4/4.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Song.h"
#import "Playlist.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSArray *songArray=[NSArray array];
        for (int i=0; i<3; i++) {
            char *name=malloc(30*sizeof(char));
            NSLog(@"输入song%i的歌名:",i);gets(name);
            NSString *nameStr=[NSString stringWithUTF8String:name];
            char *artist=malloc(20*sizeof(char));
            NSLog(@"输入song%i的艺术家:",i);gets(artist);
            NSString *artistStr=[NSString stringWithUTF8String:artist];
            char *album=malloc(30*sizeof(char));
            NSLog(@"输入song%i的专辑:",i);gets(album);
            NSString *albumStr=[NSString stringWithUTF8String:album];
            int length;
            NSLog(@"输入song%i的长度:",i);scanf("%d",&length);getchar();
            Song *song=[[Song alloc] initWithName:nameStr andArtist:artistStr andAlbum:albumStr andLength:length];
            songArray=[songArray arrayByAddingObject:song];
        }
        PlayList *playList1=[[PlayList alloc] initWithListName:@"playList1"];
    }
    return 0;
}

