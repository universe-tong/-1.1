//
//  协议.h
//  第一次作业1.3
//
//  Created by lwnlwn987 on 2019/4/1.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@protocol __ <NSObject>//必须实现
-（void)dowork;
@optional
-(void)walk;
@end

NS_ASSUME_NONNULL_END
