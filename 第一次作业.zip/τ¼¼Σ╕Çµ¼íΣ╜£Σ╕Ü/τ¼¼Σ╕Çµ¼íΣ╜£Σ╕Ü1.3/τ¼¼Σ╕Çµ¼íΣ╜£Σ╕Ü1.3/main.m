//
//  main.m
//  第一次作业1.3
//
//  Created by lwnlwn987 on 2019/4/1.
//  Copyright © 2019 刘伟楠. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
       /* //初始化方法
        NSArray *array=[[NSArray alloc] initWithObjects:
        @"zhengzhou", @"henan",@"huimian",nil];
        NSLog(@"%@",array);
      //便利构造器
        NSArray *array1=[NSArray arrayWithObjects:
        @"henan",@"zhengzhou",@"fangchenghuimian",nil];
        NSLog(@"%@",array1);
        //数组元素的个数
        NSUInteger length=[array count];
        NSLog(@"%lu",length);
        //访问数组下标元素
        NSString *str1=[array1 objectAtIndex:2];
        NSLog(@"%@",str1);
        NSString *str2=[array1 firstObject];
        NSLog(@"%@",str2);
        NSString *str3=[array1 objectAtIndex:0];
        NSLog(@"%@",str3);//效果一样 first没有元素不会崩溃，0会崩溃；
        NSString *str4=[array1 lastObject];
        NSString *str5=[array1 objectAtIndex:[array1 count]-1];
        //判断是否在数组里
        BOOL isExist = [array1 containsObject:@"henan"];
        if (isExist) {
            NSLog(@"真的有河南");
        } else {
            NSLog(@"河南去哪了");
        }
        //获取下标元素
        NSUInteger index=[array1 indexOfObject:@"henan"];
        NSLog(@"%lu",index);
        //遍历
        for(NSString *arr in array1){
            NSLog(@"%@",arr);
        }
        NSMutableArray *marray=[NSMutableArray arrayWithObjects:
        @"aaa",@"lufei",@"soulong",@"wusuopu",@"namei",nil];
        [marray addObject:@"zhangsan"];
        [marray insertObject:@"list" atIndex:0];
        
        //替换
        [marray replaceObjectAtIndex:1 withObject:@"wangwu"];
         NSLog(@"%@",marray);
        [marray exchangeObjectAtIndex:2
                    withObjectAtIndex:3];
        NSLog(@"%@",marray);
        //移除
        [marray removeObject:@"list"];
        [marray removeObjectAtIndex:0];
        NSLog(@"%@", marray);
        //便利 同不可变数组；
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:@"laowang", @"name", @"man", @"gender", @"18", @"age", nil];
        NSLog(@"%@", dic);
        NSUInteger count = [dic count];
        NSLog(@"%lu", count);
        NSString *str = [dic objectForKey:@"name"];
        NSLog(@"%@", str);
        NSArray *array = [dic allKeys];
        NSLog(@"%@", array);
        //遍历 字典遍历获取到的是key,然后根据key可获取相应的value值
        for(NSString *string in dic){
        NSLog(@"%@", [dic valueForKey:string]);
        }
        NSMutableDictionary *mdic=[[NSMutableDictionary alloc]
        initWithObjectsAndKeys:@"laowang", @"name",
        @"18", @"age", @"woman", @"gender", nil];
        NSLog(@"%@",mdic);
        [mdic setObject:@"100" forKey:@"weight"];
        NSLog(@"%@", mdic);
        [mdic setValue:@"168" forKey:@"height"];
        NSLog(@"%@", mdic); //添加的位置？
        [mdic setValue:@"16816899168" forKey:@"height"];
        NSLog(@"%@", mdic);
        //移除
        [mdic removeObjectForKey:@"weight"];
        NSLog(@"%@", mdic);
        [mdic removeAllObjects];
        NSLog(@"%@", mdic);
        NSSet *set=[NSSet setWithObjects:@"AAA",@"aaa"
        ,@"bbb",@"aaa",@"aaa",nil];
        NSLog(@"%@",set);
        NSLog(@"%lu",[set count]);
        NSString *str=[set anyObject];
        NSLog(@"%@",str);
        for (NSString *string in set) {
            NSLog(@"%@", string);*/
        NSCountedSet *countSet = [NSCountedSet setWithObjects:@"aaa", @"aaa", @"bb", @"bbb", @"aaa", @"bbb", nil];
        NSLog(@"%@", countSet);
        NSUInteger countAaa = [countSet countForObject:@"aaa"];
        NSLog(@"%lu", countAaa);
    
    }
    return 0;
}
